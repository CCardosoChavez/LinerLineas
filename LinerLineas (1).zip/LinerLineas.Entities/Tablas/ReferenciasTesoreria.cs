﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinerLineas.Entities.Tablas
{
    public class ReferenciasTesoreria
    {
        public int sEstatusDevolucionSaldo { get; set; }
        public string sCorreoUsuario { get; set; }
        public string sEstatusSolicitudDatosBancarios { get; set; }
        public string sNombreConsignatario { get; set; }
        public string sIdUsuario { get; set; }
    }
}
