﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinerLineas.Entities.Tablas
{
    public class Contenedor
    {
        public string sNOMBRE_CONTENEDOR { get; set; }
        public bool bCONTENEDOR_PAGADO { get; set; }
    }
}
