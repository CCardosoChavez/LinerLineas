﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinerLineas.Entities.Tablas
{
    public class Archivo_Recibo_Deposito_En_Garantia
    {
        public string sFSRUTA { get; set; }
        public string sFSNOMBRE { get; set; }
        public string sFSTIPO { get; set; }
        public string sFSEXTENCION { get; set; }
        public string sFSRUTA_COMPLETA_ARCHIVO { get; set; }
    }
}
