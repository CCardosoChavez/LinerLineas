﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LinerLineas.Entities.PagoReferenciado;

namespace LinerLineas.Entities.PagoReferenciado
{
    public class AspNetUsersRoles
    {
        public AspNetUsers rASPNET_USERS { get; set; }
        public AspNetRoles rASPNER_ROLES { get; set; }
    }
}
