﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinerLineas.Entities.PagoReferenciado
{
    public class Cliente
    {
        public int nIdCliente { get; set; }
        public string sRFC { get; set; }
        public string sRazonSocial { get; set; }
        public string sAccountNum { get; set; }
        public string srecId { get; set; }
    }
}
