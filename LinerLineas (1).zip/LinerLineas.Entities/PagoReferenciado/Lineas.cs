﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinerLineas.Entities.PagoReferenciado
{
    public class Lineas
    {
        public int nIdLinea { get; set; }
        public string sNombre { get; set; }
        public string sAbreviacion { get; set; }
        public int nNumLinea { get; set; }
        public string sDataAreaId { get; set; }
        public int nIdLineaAX { get; set; }

    }
}
