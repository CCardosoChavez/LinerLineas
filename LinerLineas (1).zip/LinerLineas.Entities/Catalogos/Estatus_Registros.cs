﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinerLineas.Entities.Catalogos
{
    public class Estatus_Registros
    {
        public int nFIIDESTATUS { get; set; } //FIIDESTATUS
        public string sFSESTATUS { get; set; } //FSESTATUS
        public DateTime daFDALTA { get; set; } //FDALTA
    }
}
