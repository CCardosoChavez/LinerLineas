﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinerLineas.Entities.Catalogos
{
    public class Estatus_Dano_Contenedores
    {
        public int nFIIDESTATUS_DANO_CONTENEDORES { get; set; }
        public string sESTATUS { get; set; }
    }
}
