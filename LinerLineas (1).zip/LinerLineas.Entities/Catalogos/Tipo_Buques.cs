﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinerLineas.Entities.Catalogos
{
    public class Tipo_Buques
    {
        public int nTIPO_BUQUE { get; set; }
        public string sDESC_TB { get; set; }
    }
}
