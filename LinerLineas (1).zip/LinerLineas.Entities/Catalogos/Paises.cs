﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinerLineas.Entities.Catalogos
{
    public class Paises
    {
        public int nNUM_PAIS { get; set; }
        public string sNOM_PAIS { get; set; }
        public string sNACION { get; set; }
        public string sLADA_PAIS { get; set; }
        public string sCVE_PAIS { get; set; }
        public string sCVE_SBO { get; set; } // CHAR
    }
}
