﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinerLineas.Entities
{
    public class USRS
    {
        public string USR { get; set; }
        public string PWD { get; set; }
        public int NUM_EMP { get; set; }
        public char? ADMIN { get; set; }
        public char? STATUS { get; set; }
    }
}
