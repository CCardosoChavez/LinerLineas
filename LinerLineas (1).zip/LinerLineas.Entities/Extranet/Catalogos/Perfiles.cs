﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinerLineas.Entities.Extranet.Catalogos
{
    public class Perfiles
    {
        public int nFIIDPERFIL { get; set; }
        public string sFSPERFIL { get; set; }
        public DateTime daFDALTA { get; set; }
        public int nFIIDESTATUS { get; set; }
    }
}
