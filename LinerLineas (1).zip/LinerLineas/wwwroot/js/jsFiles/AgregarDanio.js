﻿document.querySelector('#btnAgregarDesperfecto').addEventListener('click', () => {
    validacionTipoDano();
});